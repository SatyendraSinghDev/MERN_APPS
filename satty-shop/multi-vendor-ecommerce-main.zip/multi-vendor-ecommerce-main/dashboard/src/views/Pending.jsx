import React from 'react'

const Pending = () => {
  return (
    <div>Pending</div>
  )
}

export default Pending