import React from 'react'

const Deactive = () => {
    return (
        <div>Deactive</div>
    )
}

export default Deactive